@include($activeTemplate . 'partials.buy_sell_list', [
    'take' => 6,
    'type' => 'buy'
])
