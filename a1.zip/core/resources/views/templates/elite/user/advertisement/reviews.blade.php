@extends($activeTemplate . 'layouts.master_without_menu')
@section('content')
    @include($activeTemplate . 'partials.reviews')
@endsection
